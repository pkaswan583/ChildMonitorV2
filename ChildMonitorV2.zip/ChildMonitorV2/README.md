# ChildMonitor - Child Device App

Android 15 + Oppo A17 Compatible

## Setup Steps:
1. Add Firebase `google-services.json` as GitHub Secret named `GOOGLE_SERVICES_JSON`
2. Push to main branch
3. Download APK from Actions > Artifacts
