package com.childmonitor.services;

import android.app.Service;
import android.app.usage.UsageStats;
import android.app.usage.UsageStatsManager;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;

import androidx.annotation.Nullable;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class AppUsageService extends Service {

    private Handler handler;
    private Runnable runnable;
    private DatabaseReference usageRef;
    private String currentApp = "";

    @Override
    public void onCreate() {
        super.onCreate();
        String deviceId = getSharedPreferences("cm_prefs", MODE_PRIVATE)
                .getString("device_id", "unknown");
        usageRef = FirebaseDatabase.getInstance()
                .getReference("devices").child(deviceId).child("app_usage");
        handler = new Handler(Looper.getMainLooper());
        startTracking();
    }

    private void startTracking() {
        runnable = new Runnable() {
            @Override
            public void run() {
                checkCurrentApp();
                trackDailyUsage();
                handler.postDelayed(this, 5 * 60 * 1000);
            }
        };
        handler.post(runnable);
    }

    private void checkCurrentApp() {
        UsageStatsManager usm = (UsageStatsManager) getSystemService(Context.USAGE_STATS_SERVICE);
        long now = System.currentTimeMillis();
        List<UsageStats> list = usm.queryUsageStats(
                UsageStatsManager.INTERVAL_DAILY, now - 10000, now);
        if (list == null || list.isEmpty()) return;
        UsageStats recent = null;
        for (UsageStats s : list) {
            if (recent == null || s.getLastTimeUsed() > recent.getLastTimeUsed()) recent = s;
        }
        if (recent == null) return;
        String pkg = recent.getPackageName();
        if (!pkg.equals(currentApp) && !pkg.startsWith("com.android.") && !pkg.equals("com.childmonitor")) {
            currentApp = pkg;
            Map<String, Object> data = new HashMap<>();
            data.put("package", pkg);
            data.put("app_name", getAppName(pkg));
            data.put("time", new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date()));
            data.put("timestamp", System.currentTimeMillis());
            usageRef.child("current_app").setValue(data);
            String dateKey = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());
            usageRef.child("opens").child(dateKey).child(String.valueOf(System.currentTimeMillis())).setValue(data);
        }
    }

    private void trackDailyUsage() {
        UsageStatsManager usm = (UsageStatsManager) getSystemService(Context.USAGE_STATS_SERVICE);
        long now = System.currentTimeMillis();
        List<UsageStats> stats = usm.queryUsageStats(
                UsageStatsManager.INTERVAL_DAILY, now - 86400000L, now);
        if (stats == null) return;
        String dateKey = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());
        Map<String, Object> daily = new HashMap<>();
        for (UsageStats s : stats) {
            if (s.getTotalTimeInForeground() > 60000) {
                Map<String, Object> app = new HashMap<>();
                app.put("app_name", getAppName(s.getPackageName()));
                app.put("usage_minutes", s.getTotalTimeInForeground() / 60000);
                daily.put(s.getPackageName().replace(".", "_"), app);
            }
        }
        usageRef.child("daily").child(dateKey).setValue(daily);
    }

    private String getAppName(String pkg) {
        try {
            return getPackageManager().getApplicationLabel(
                    getPackageManager().getApplicationInfo(pkg, 0)).toString();
        } catch (Exception e) {
            return pkg;
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (handler != null) handler.removeCallbacks(runnable);
        startService(new Intent(this, AppUsageService.class));
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) { return null; }
}
