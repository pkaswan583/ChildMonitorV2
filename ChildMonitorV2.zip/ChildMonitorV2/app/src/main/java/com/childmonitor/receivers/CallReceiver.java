package com.childmonitor.receivers;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.telephony.TelephonyManager;

import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;
import java.util.Map;

public class CallReceiver extends BroadcastReceiver {

    private static long callStart = 0;
    private static String lastNum = "";

    @Override
    public void onReceive(Context ctx, Intent intent) {
        String deviceId = ctx.getSharedPreferences("cm_prefs", Context.MODE_PRIVATE)
                .getString("device_id", "unknown");
        com.google.firebase.database.DatabaseReference ref = FirebaseDatabase.getInstance()
                .getReference("devices").child(deviceId).child("communications").child("calls");

        if (TelephonyManager.ACTION_PHONE_STATE_CHANGED.equals(intent.getAction())) {
            String state = intent.getStringExtra(TelephonyManager.EXTRA_STATE);
            String num = intent.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER);
            if (TelephonyManager.EXTRA_STATE_RINGING.equals(state)) {
                lastNum = num != null ? num : "Unknown";
                log(ref, lastNum, "ringing");
            } else if (TelephonyManager.EXTRA_STATE_OFFHOOK.equals(state)) {
                callStart = System.currentTimeMillis();
                log(ref, lastNum, "connected");
            } else if (TelephonyManager.EXTRA_STATE_IDLE.equals(state) && callStart > 0) {
                int dur = (int) ((System.currentTimeMillis() - callStart) / 1000);
                Map<String, Object> d = new HashMap<>();
                d.put("number", lastNum);
                d.put("type", "ended");
                d.put("duration_sec", dur);
                d.put("timestamp", System.currentTimeMillis());
                ref.child(String.valueOf(System.currentTimeMillis())).setValue(d);
                callStart = 0;
            }
        }
        if (Intent.ACTION_NEW_OUTGOING_CALL.equals(intent.getAction())) {
            lastNum = intent.getStringExtra(Intent.EXTRA_PHONE_NUMBER);
            log(ref, lastNum != null ? lastNum : "Unknown", "outgoing");
        }
    }

    private void log(com.google.firebase.database.DatabaseReference ref, String num, String type) {
        Map<String, Object> d = new HashMap<>();
        d.put("number", num);
        d.put("type", type);
        d.put("timestamp", System.currentTimeMillis());
        ref.child(String.valueOf(System.currentTimeMillis())).setValue(d);
    }
}
