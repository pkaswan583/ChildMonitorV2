package com.childmonitor.receivers;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.telephony.SmsMessage;

import com.childmonitor.services.CallSmsService;

public class SmsReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context ctx, Intent intent) {
        if (!"android.provider.Telephony.SMS_RECEIVED".equals(intent.getAction())) return;
        Bundle b = intent.getExtras();
        if (b == null) return;
        Object[] pdus = (Object[]) b.get("pdus");
        if (pdus == null) return;
        String format = b.getString("format");
        StringBuilder body = new StringBuilder();
        String from = "";
        for (Object pdu : pdus) {
            SmsMessage msg = SmsMessage.createFromPdu((byte[]) pdu, format);
            body.append(msg.getMessageBody());
            from = msg.getOriginatingAddress();
        }
        Intent si = new Intent(ctx, CallSmsService.class);
        si.putExtra("new_sms", true);
        si.putExtra("sms_number", from);
        si.putExtra("sms_body", body.toString());
        ctx.startService(si);
    }
}
