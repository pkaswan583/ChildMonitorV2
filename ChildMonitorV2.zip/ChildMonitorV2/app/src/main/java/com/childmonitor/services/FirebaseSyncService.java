package com.childmonitor.services;

import android.app.Service;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;

import androidx.annotation.Nullable;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;
import java.util.Map;

public class FirebaseSyncService extends Service {

    private Handler handler;
    private Runnable runnable;
    private DatabaseReference deviceRef;
    private String deviceId;

    @Override
    public void onCreate() {
        super.onCreate();
        deviceId = getSharedPreferences("cm_prefs", MODE_PRIVATE)
                .getString("device_id", "unknown");
        deviceRef = FirebaseDatabase.getInstance()
                .getReference("devices").child(deviceId);
        FirebaseDatabase.getInstance().setPersistenceEnabled(true);
        registerDevice();
        handler = new Handler(Looper.getMainLooper());
        runnable = new Runnable() {
            @Override
            public void run() {
                sendHeartbeat();
                handler.postDelayed(this, 60000);
            }
        };
        handler.post(runnable);
    }

    private void registerDevice() {
        Map<String, Object> info = new HashMap<>();
        info.put("model", android.os.Build.MODEL);
        info.put("android", android.os.Build.VERSION.RELEASE);
        info.put("registered_at", System.currentTimeMillis());
        info.put("device_id", deviceId);
        deviceRef.child("info").setValue(info);
    }

    private void sendHeartbeat() {
        Map<String, Object> hb = new HashMap<>();
        hb.put("last_seen", System.currentTimeMillis());
        hb.put("battery", getBattery());
        hb.put("online", isOnline());
        deviceRef.child("heartbeat").setValue(hb);
    }

    private int getBattery() {
        Intent i = registerReceiver(null,
                new android.content.IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        if (i == null) return -1;
        int lvl = i.getIntExtra(android.os.BatteryManager.EXTRA_LEVEL, -1);
        int scale = i.getIntExtra(android.os.BatteryManager.EXTRA_SCALE, -1);
        return (int) ((lvl / (float) scale) * 100);
    }

    private boolean isOnline() {
        ConnectivityManager cm = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
        NetworkInfo ni = cm.getActiveNetworkInfo();
        return ni != null && ni.isConnected();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) { return START_STICKY; }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (handler != null) handler.removeCallbacks(runnable);
        startService(new Intent(this, FirebaseSyncService.class));
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) { return null; }
}
