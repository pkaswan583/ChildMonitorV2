package com.childmonitor.services;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.IBinder;

import androidx.annotation.Nullable;

import com.google.firebase.database.FirebaseDatabase;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class DailyReportService extends Service {

    private String deviceId;

    @Override
    public void onCreate() {
        super.onCreate();
        deviceId = getSharedPreferences("cm_prefs", MODE_PRIVATE)
                .getString("device_id", "unknown");
        scheduleReport();
    }

    private void scheduleReport() {
        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.HOUR_OF_DAY, 23);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);
        if (cal.getTimeInMillis() < System.currentTimeMillis()) {
            cal.add(Calendar.DAY_OF_MONTH, 1);
        }
        Intent i = new Intent(this, DailyReportService.class);
        i.setAction("GENERATE");
        PendingIntent pi = PendingIntent.getService(this, 0, i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        AlarmManager am = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        if (am != null) {
            am.setRepeating(AlarmManager.RTC_WAKEUP, cal.getTimeInMillis(),
                    AlarmManager.INTERVAL_DAY, pi);
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && "GENERATE".equals(intent.getAction())) {
            generateReport();
        }
        return START_STICKY;
    }

    private void generateReport() {
        String today = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());
        Map<String, Object> report = new HashMap<>();
        report.put("date", today);
        report.put("generated_at", System.currentTimeMillis());
        FirebaseDatabase.getInstance()
                .getReference("devices").child(deviceId)
                .child("daily_reports").child(today).setValue(report);
        Map<String, Object> notif = new HashMap<>();
        notif.put("type", "daily_report");
        notif.put("date", today);
        notif.put("timestamp", System.currentTimeMillis());
        FirebaseDatabase.getInstance()
                .getReference("notifications").child(deviceId).push().setValue(notif);
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) { return null; }
}
