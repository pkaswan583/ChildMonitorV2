package com.childmonitor.receivers;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import com.childmonitor.services.AppUsageService;
import com.childmonitor.services.CallSmsService;
import com.childmonitor.services.DailyReportService;
import com.childmonitor.services.FirebaseSyncService;
import com.childmonitor.services.LocationService;
import com.childmonitor.services.SurroundingSoundService;

public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context ctx, Intent intent) {
        String action = intent.getAction();
        if (Intent.ACTION_BOOT_COMPLETED.equals(action) ||
            "android.intent.action.QUICKBOOT_POWERON".equals(action)) {
            for (Class<?> cls : new Class[]{
                LocationService.class, AppUsageService.class, CallSmsService.class,
                SurroundingSoundService.class, FirebaseSyncService.class, DailyReportService.class
            }) {
                ctx.startForegroundService(new Intent(ctx, cls));
            }
        }
    }
}
