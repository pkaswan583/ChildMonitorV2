package com.childmonitor.services;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class WebBlockerService extends AccessibilityService {

    private List<String> blockedList = new ArrayList<>();
    private DatabaseReference blockedRef;
    private String deviceId;

    @Override
    public void onServiceConnected() {
        super.onServiceConnected();
        AccessibilityServiceInfo info = new AccessibilityServiceInfo();
        info.eventTypes = AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED |
                          AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED;
        info.feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC;
        info.flags = AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS |
                     AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS;
        info.notificationTimeout = 100;
        setServiceInfo(info);

        deviceId = getSharedPreferences("cm_prefs", MODE_PRIVATE)
                .getString("device_id", "unknown");

        blockedList.add("porn");
        blockedList.add("xxx");
        blockedList.add("adult");
        blockedList.add("gambling");
        blockedList.add("bet365");

        blockedRef = FirebaseDatabase.getInstance()
                .getReference("devices").child(deviceId).child("blocked_sites");
        blockedRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snap) {
                blockedList.clear();
                blockedList.add("porn");
                blockedList.add("xxx");
                blockedList.add("adult");
                for (DataSnapshot s : snap.getChildren()) {
                    String val = s.getValue(String.class);
                    if (val != null) blockedList.add(val.toLowerCase());
                }
            }
            @Override
            public void onCancelled(DatabaseError e) {}
        });
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null) return;
        String pkg = String.valueOf(event.getPackageName());
        if (!pkg.contains("chrome") && !pkg.contains("firefox") &&
            !pkg.contains("browser") && !pkg.contains("opera") &&
            !pkg.contains("brave")) return;

        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return;
        List<AccessibilityNodeInfo> nodes = root.findAccessibilityNodeInfosByViewId(
                "com.android.chrome:id/url_bar");
        if (nodes == null || nodes.isEmpty()) return;
        AccessibilityNodeInfo urlBar = nodes.get(0);
        if (urlBar == null || urlBar.getText() == null) return;
        String url = urlBar.getText().toString().toLowerCase();
        for (String blocked : blockedList) {
            if (url.contains(blocked)) {
                performGlobalAction(GLOBAL_ACTION_BACK);
                performGlobalAction(GLOBAL_ACTION_HOME);
                FirebaseDatabase.getInstance()
                        .getReference("devices").child(deviceId)
                        .child("blocked_attempts")
                        .child(String.valueOf(System.currentTimeMillis()))
                        .setValue(url);
                return;
            }
        }
    }

    @Override
    public void onInterrupt() {}
}
